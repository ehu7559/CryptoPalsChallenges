#DSA parameter tampering
from s4c28 import SHA1
from s6c43 import DSA

if __name__ == "__main__":
    chall_p = 0x800000000000000089e1855218a0e7dac38136ffafa72eda7859f2171e25e65eac698c1702578b07dc2a1076da241c76c62d374d8389ea5aeffd3226a0530cc565f3bf6b50929139ebeac04f48c3c84afb796d61e5a4f9a8fda812ab59494232c7d2b4deb50aa18ee9e132bfa85ac4374d7f9091abc3d015efc871a584471bb1
    chall_q = 0xf4f47f05794b256174bba6e9b396a7707e563c5                              

    #Sample message to be signed and its hash.
    message = "x ain't gon' be given to ya".encode() #hahaaaa math joke.
    
    #Generate Malicious Parameters
    mal_params_0 = DSA.gen_params(chall_p, chall_q, 0)
    mal_params_1 = DSA.gen_params(chall_p, chall_q, 1)

    #Generate demonstration key-pairs.
    
    #Generate demonstration signatures

    #Demonstration Verifications with arbitrary messages