class DataHelper:
    def decode_uint_be(buf : bytes) -> int:
        '''parses a big-endian unsigned integer from a bytes object'''
        output = 0
        buf = bytearray(buf)
        while buf:
            output = output << 8
            output += buf.pop(0)
        return output

    def decode_uint_le(buf : bytes) -> int:
        '''parses a little-endian unsigned integer from a bytes object'''
        output = 0
        buf = bytearray(buf)
        while buf:
            output = output << 8
            output += buf.pop()
        return output
    
    def encode_uint_be(num : int, length : int) -> bytes:
        '''Encodes a big-endian unsigned integer in a bytes object'''
        assert length > 0
        mask = (0x1 << (length << 3)) - 1
        num = num & mask
        output = bytearray()
        while num:
            output.extend(num & 0xFF)
            num = num >> 8    
        output.extend(bytearray(length - len(output)))
        return bytes(output)


    def encode_uint_le(num : int, length : int) -> bytes:
        '''Encodes a little-endian unsigned integer in a bytes object'''
        pass

    def join_buffers(buffers : list[bytes]) -> bytes:
        output = bytearray()
        for buf in buffers:
            output.extend(buf)
        return output