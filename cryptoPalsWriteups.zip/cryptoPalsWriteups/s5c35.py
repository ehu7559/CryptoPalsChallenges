#Challenge 35: Implement DH with negotiated groups, and break with malicious "g" parameters

#TODO: This challenge is easy enough and is of low importance. I will complete it at a later date.

if __name__ == "__main__":
    print("--- CHALLENGE STATUS: TODO ---")